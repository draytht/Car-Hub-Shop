package carshop.carshop;

public interface Dialog_Interface {
     public void purchaseSuccessful();
     public void signOutSuccessful();
     public void LoginSuccessful();
     public void SignUpSuccessful();
     public void deleteSuccessful();
    public void purchaseFailed();
    public void LoginFailed();
    public void SignUpFailed();
    public void deleteFailed();
    public void AddListSuccessful();
    public void sold();



}
